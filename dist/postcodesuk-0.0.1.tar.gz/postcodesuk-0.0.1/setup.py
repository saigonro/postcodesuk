from setuptools import setup

setup(
    name='postcodesuk',
    version='0.0.1',
    description='a pip-installable package that formats and validates post codes for UK',
    packages=['postcodesuk'],
    author='Dan Dumitrache',
    author_email='vietnamezul@gmail.com',
    url='https://github.com/saigonro/postcodesuk'
)
